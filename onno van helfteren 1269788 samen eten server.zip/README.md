# avans-1.4-nodejs-project

## Node API server file structure

- Server start in `server.js`
- Tests in `test/..`
- DAO/Controllers in `app/..`
